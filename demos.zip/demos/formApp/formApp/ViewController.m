//
//  ViewController.m
//  formApp
//
//  Created by LuoYiJia on 16/3/22.
//  Copyright © 2016年 Urgoo. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor =[UIColor redColor];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"app2://"]]) {
        //后跟的是参数
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"app2://canshu"]];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
